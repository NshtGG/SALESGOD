# Sales God

A live sales copilot. It hears the prospect through your speakers, tracks where you are in your closing script, and writes the exact next line for you to say.

Built on your VIP closing script and objection formula. Runs on free Chinese models through OpenRouter.

---

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:5173 **in Chrome or Edge**. Firefox and Safari cannot capture audio and the live view will tell you so.

To deploy: `npm run build`, then drop the `dist/` folder on Vercel, Netlify, or Cloudflare Pages. It is a static site with no backend, so hosting is free.

---

## Two keys, both free

**OpenRouter** — the coaching brain. Sign up at openrouter.ai, make a key, paste it into Settings. Default model is DeepSeek V3, which is free and fast enough to keep up with a live call. GLM 4.5 Air, Qwen3 and Kimi K2 are also wired in.

**Speech-to-text** — turning the prospect's voice into text. Two presets in Settings:
- SiliconFlow SenseVoice (Chinese, free credits on signup)
- Groq Whisper Turbo (free tier, noticeably faster)

Your own voice does not use either — Chrome's built-in recogniser handles your side for nothing.

Both keys are stored in your browser's local storage. Nothing else leaves the machine.

---

## Running a call

1. Start the call in **Google Meet or Zoom in a browser tab**. Not the Zoom desktop app.
2. In Sales God, go to Live call and hit **Start listening**.
3. Chrome asks what to share. Pick that tab and **tick "Also share tab audio"**. Without the tick there is no audio and the app will say so.
4. Hit **Float the cue** to pop the line out into a small always-on-top window you can park beside the call.
5. Talk. Your line updates roughly a second after the prospect stops speaking.
6. Hit **End call**, then **Score this call**.

On Windows you can pick "Entire Screen" and "Share system audio" instead, which catches the Zoom desktop app too. macOS Chrome only does tab audio — to capture the Zoom desktop app there you would need a virtual audio device like BlackHole routed as your output.

---

## What's in it

**Live call** — dual transcript with you and the prospect separated, a cue card with your next line, a stage rail showing whether you are in Intent, Logical certainty, Emotional certainty or Pitch, and an objection panel that fires the instant a trigger phrase lands. There is also a text box to type what the prospect said if the audio drops a line.

**Roleplay** — the model plays a prospect. Four personas skewed to roofing and construction, three difficulty levels. Brutal mode interrupts and price-anchors early. Score it afterwards like a real call.

**Debrief** — score out of 100, measured talk ratio, stage-by-stage coverage, what worked, what cost you, and three things to do differently. Graded against your playbook rather than a generic rubric, and deliberately blunt.

**Playbook** — your script, editable. Fill in the offer block first: what you sell, the problem, the avatar, the price you say out loud, and your three pillars. Every placeholder in a live cue gets filled from this plus what the prospect actually said, so an empty offer block means generic lines.

**Objections** — Money, Time and Partner, plus the Island, What's Riskier, Decision Making Process and 4000 Dots frames. Searchable.

---

## Things that will bite you

**Free tier rate limits.** OpenRouter's free models cap requests per minute. On a long call you may see a 429. Bump the audio slice length in Settings from 5 seconds to 8 to cut request volume, or switch model.

**Free model IDs churn.** OpenRouter retires `:free` variants regularly. If a model starts 404ing, check openrouter.ai/models and update the list in `src/lib/store.ts`.

**Transcription lags about a second.** Audio is captured in slices, and a slice has to finish before it can be transcribed. Shorter slices mean faster cues but more requests.

**Reasoning models are too slow.** DeepSeek R1 is in the list because it grades debriefs well, but do not use it live — it thinks for several seconds before answering.

**Consent.** You are transcribing someone else's voice. Several US states, the UK and most of the EU require them to know. "I've got a notetaker running, that alright?" in your opener covers you nearly everywhere. Do not skip it.

---

## Layout

```
src/
  data/playbook.ts   your script and objection formula as structured data
  lib/audio.ts       system audio capture, chunked recording, mic recognition
  lib/coach.ts       prompts for the live cue, roleplay and scorecard
  lib/openrouter.ts  API client, plus JSON extraction for models that ramble
  lib/store.ts       settings and playbook persistence
  views/             one file per tab
```

The place to tune quality is `src/lib/coach.ts`. `CUE_SYSTEM` controls how the live line is written — that prompt is what decides whether the app feels sharp or generic.
