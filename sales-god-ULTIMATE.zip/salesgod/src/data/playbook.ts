// The VIP closing script and objection formula, structured so the model can
// reason over them instead of being handed a wall of prose.

export type Line = { say: string; note?: string };

export type Stage = {
  id: string;
  name: string;
  purpose: string;
  outcome: string;
  lines: Line[];
  advanceWhen: string;
};

export type Objection = {
  id: string;
  name: string;
  kind: 'objection' | 'frame';
  triggers: string[];
  steps: string[];
};

export const STAGES: Stage[] = [
  {
    id: 'intent',
    name: 'Intent',
    purpose: "Sound like you don't hate your life, and get the overarching goal.",
    outcome: 'Their goal, in their words.',
    lines: [
      { say: 'Hey — can you hear me, can you see me?' },
      { say: "What's up buddy, how's it going?", note: 'Super casual. Do not sound like a script.' },
      { say: 'Cool man — looks like you booked a time about possible help with {goal}? Is that right?' },
      {
        say: "Ok easy man, and just to see if I can help — what's sorta like the, the, the main goal of looking at this?",
        note: 'The stumble is deliberate. It reads as unrehearsed.',
      },
    ],
    advanceWhen: 'They have stated a goal you can repeat back to them.',
  },
  {
    id: 'logical',
    name: 'Logical certainty',
    purpose: 'Get their current strategy, the problem with it, and probe.',
    outcome: 'Their situation, the catalyst, and pain you have expanded.',
    lines: [
      { say: 'What are you doing right now to achieve {goal}?' },
      { say: 'How long have you been doing {strategy}?' },
      { say: 'What caused you to use {strategy} in the first place?' },
      {
        say: "I mean {strategy} doesn't sound bad, it's pretty common… what's changed now? That has you looking at this rather than just carrying on with that.",
        note: 'This one gets the catalyst. Do not skip it.',
      },
      { say: 'What do you mean? / How do you mean? / Meaning?', note: 'Expand the pain. Say less.' },
      { say: 'How long has that been going on for?' },
      { say: 'Has {problem} had an impact on {other area}?' },
    ],
    advanceWhen: 'You have a named problem, a catalyst, and at least one knock-on consequence.',
  },
  {
    id: 'emotional',
    name: 'Emotional certainty',
    purpose: 'Pre-handle objections, future pace the win, then the consequence.',
    outcome: 'Two or three specific goals, and what happens if nothing changes.',
    lines: [
      {
        say: "Ok, and just so I see your POV — besides {problem}, what's the main reason you might be looking at outside help rather than just doubling down on {strategy}, like most people do?",
        note: 'Pre-handles the DIY objection before they can raise it.',
      },
      {
        say: 'And before you and I were speaking, were you out there looking for more advanced help with {goal}, or what were you doing?',
        note: 'Follow with: What prevented you? So what has shifted now?',
      },
      {
        say: "If I can offer a perspective — you know Usain Bolt? Fastest runner alive. Put him on a 100m track, he runs fast, because there's a medal at the end. Release a lion behind him and he runs faster, because now there's a consequence to failing. So for you — what's the medal?",
        note: 'Optional pre-frame. Use it when they are flat.',
      },
      {
        say: "Let's say there was a way of helping you with {problem} — what would tangibly be different for you or the business at that point?",
        note: 'Get two or three specific goals.',
      },
      { say: 'And accomplishing that — step into those shoes for a second — what would that mean for you, like personally though?' },
      {
        say: "So on the flip side — what if you don't? What happens if {problem} carries on and we don't get to {goal} for the next two days, two weeks, two months, even two years?",
        note: 'Get two or three specific consequences.',
      },
      { say: 'And how would you feel… in those shoes?' },
    ],
    advanceWhen: 'They have said the consequence out loud and reacted to it.',
  },
  {
    id: 'close',
    name: 'Pitch and close',
    purpose: 'Commit them to change, deliver three pillars, tie down.',
    outcome: 'A decision, or a named objection to handle.',
    lines: [
      { say: "This'll sound like an obvious question but it's not — are you willing to settle for that?" },
      {
        say: "And why now? There's always the new-year-new-me guy, the diet that starts on a Monday. Why actually draw the line now?",
        note: 'You have not for the past months. Make them justify the timing.',
      },
      { say: "And whose responsibility is it?" },
      {
        say: "Based on what I've heard — {problems} and {goals} — I think what we're doing could genuinely help. If it'd be appropriate, we can put a game plan together for how to actually get you to {goal}. Would that be appropriate, or what do you want to do?",
      },
      {
        say: 'Pillar one is {pillar}. Because you know how you mentioned {problem}? That is why pillar one exists — so that {how it solves it}. Do you see how that would help?',
        note: 'Repeat for all three pillars. Every pillar maps to something they said.',
      },
      { say: "Based on what I've covered, do you feel like this would actually get you to {goal}?" },
      { say: 'And why though? What do you feel is the key to the castle for you?' },
      { say: 'And how do you feel that would help you specifically?' },
      {
        say: 'Great — so the total investment to get {program}, so you can {goals}, is {price}. How would you like to proceed?',
        note: 'Say the number. Then stop talking.',
      },
    ],
    advanceWhen: 'They buy, or they object — go to the objection handler.',
  },
];

export const OBJECTIONS: Objection[] = [
  {
    id: 'money',
    name: 'Money',
    kind: 'objection',
    triggers: [
      "can't afford", 'too expensive', 'no budget', 'out of my price range', 'cost',
      'how much', 'pricey', 'money is tight', 'cash flow', 'thats a lot',
    ],
    steps: [
      'Ok, not a problem. Money aside — if I gave you a duffel bag with {amount}, would you do it?',
      'Why though?',
      'Cause what would that do for you personally?',
      'So is it just that initial investment of {amount}, or if there was a way to break it up, would that make it more digestible?',
      'So cash on hand, besides bills and expenses, what do you have available — just to see if I can help?',
      'Build a payment plan inside their real constraint, then tie down.',
      'Ok — so with the understanding you feel it gets you to {goal}, and it works within your budget, how would you like to proceed?',
    ],
  },
  {
    id: 'time',
    name: 'Time',
    kind: 'objection',
    triggers: [
      'no time', "don't have time", 'too busy', 'swamped', 'bandwidth',
      'later in the year', 'after the quarter', 'next quarter', 'not right now',
    ],
    steps: [
      "Time aside — if you did have the time, would you do it? Do you feel it'd get you to {goal}?",
      'Why though? Cause what would that do for you personally?',
      "There are two people in this world. The first says I have X, Y and Z so I can't do {goal}. The second says I have X, Y and Z, which is why I have to. Which do you want to be?",
      "And why? Cause you don't have to, man.",
      'Because what do you think happens if you don\'t? If you decide to be that first guy?',
      'And are you actually willing to… settle for that?',
      'So what decision do you have to make to put yourself in the best possible position to {goal}?',
    ],
  },
  {
    id: 'partner',
    name: 'Partner or spouse',
    kind: 'objection',
    triggers: [
      'my wife', 'my husband', 'my partner', 'talk to my', 'run it by',
      'check with', 'speak to my business partner', 'we decide together',
    ],
    steps: [
      "Partner aside — if she was on board and said \"honey you have to do this\", would you actually do it? Do you feel it'd get you to {goal}?",
      'Why though? Cause what would that do for you personally?',
      'Have you heard the saying "heavy is the head that wears the crown"? The weight isn\'t the crown, it\'s the decisions you make wearing it. The king sent armies out — responsible for hundreds of thousands of lives — because it wouldn\'t be fair to put that burden on anybody but himself.',
      "So who's going to be the one doing this — you, or your wife?",
      "So whose responsibility is it to put you in the best possible position to {goal}?",
      'Do you think it would be fair to put that responsibility on anybody but yourself? Why not?',
      'Because what happens if you take the responsibility and power you have, and put it in the hands of someone with less context?',
      'And are you actually willing to settle for that? So what decision do you have to make?',
    ],
  },
  {
    id: 'island',
    name: 'Island analogy',
    kind: 'frame',
    triggers: ['think about it', 'need to think', 'not sure', 'let me sit on it', 'get back to you'],
    steps: [
      "We all make decisions based on our perspective. The hard thing is making decisions based on where you want to go, not where you are — because if I keep deciding from where I am, that's the only place I end up.",
      "It's like being on an island with seventeen miles of water in every direction. Every decision you make is based on being on that island with limited resources. But if my goal is the mountain — because on a mountain I see the woods, the trees, the world for what it is — how do I get there when I can't even see it?",
      "Step one: believe there's a mountain. Do you believe achieving {goal} is possible?",
      "Step two: strap the shoes on. You've done that — you hopped on this call and made a plan you feel gets you there, right?",
      'Step three: start swimming. Because I can spend two days, two weeks, two months, two years walking around that island and the view does not change. North, south, east, west — the water is still the water.',
      'So what do you feel you have to do to get off the island to the mountain?',
      "Push back: well, you don't have to. Every good diet starts on a Monday.",
      'Consequence: what happens if you do nothing and stay on the island with the same view?',
      "Call to action: so what do you have to do, so that when your head hits the bed tonight you've done everything to get {goal}?",
    ],
  },
  {
    id: 'riskier',
    name: "What's riskier",
    kind: 'frame',
    triggers: ['risky', 'risk', 'what if it doesnt work', 'no guarantee', 'burned before'],
    steps: [
      "Ok man — but what's riskier? Is it riskier that you get the funding, we train you, and you get {results}? Or is it riskier that you do nothing, never get there, and nothing changes?",
      'Push back: but why though? Why is it riskier to not do anything?',
      'Consequence: because what happens if you continue to not do anything?',
      "Call to action: so what do you feel we should do to make {goal} a reality, so you don't settle for {consequence}?",
    ],
  },
  {
    id: 'decisions',
    name: 'Decision-making process',
    kind: 'frame',
    triggers: ['maybe later', 'push it off', 'not a priority', 'revisit', 'down the line'],
    steps: [
      "We all have a decision-making process. Someone overweight has a bad one around health. I might have great health and terrible finances — bad process around money. What changes for people is when they change how they decide.",
      'So scale of one to ten — one is not happy, ten is you would not change a thing — how happy are you with {area}?',
      'Ok, a five. What does a ten look like? Let them talk for a full minute or two.',
      "Why do you feel you're only a five?",
      'So how much longer do you want to let the same decision-making process that got you to a five keep affecting your results?',
      'Push back: why not? You could push it off another month, six months, a year.',
      'Consequence: what happens if you keep the same process and keep pushing it off?',
      'Call to action: so what changes do you need to make right now in how you decide, to become the person that gets {result}?',
    ],
  },
  {
    id: 'dots',
    name: '4000 dots',
    kind: 'frame',
    triggers: ['someday', 'eventually', 'no rush', 'been meaning to', 'for years'],
    steps: [
      'I have a calendar in my office with four thousand dots. Know what they represent? A week. The average human lives about four thousand weeks, and every time one passes I circle a dot.',
      "It does two things: I realise how much time I have left, and how much I've had. And every time I circle one I ask — have I done everything to get to my outcome? And if not, why not?",
      "At forty, half the dots are gone. Of the two thousand left, a third goes to sleeping, so you've got fifteen hundred. Eating, driving, the rest — call it another two-fifty. So you've got twelve-fifty weeks. Then it's done.",
      'How much time has gone by where you are not where you want to be, and you are not taking action to get there?',
      'Push back: so why change now, and not just keep doing what you did for the last two hundred dots?',
      'Consequence: what happens if you keep circling dots knowing you are not where you want to be?',
      "Call to action: so what do you need to do, so the next time you circle a dot you feel you've actually done something?",
    ],
  },
];

export const DEFAULT_PROFILE = {
  offer: '',
  problemSolved: '',
  avatar: '',
  price: '',
  pillars: ['', '', ''],
};

export type Profile = typeof DEFAULT_PROFILE;
