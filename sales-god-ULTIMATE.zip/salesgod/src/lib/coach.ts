import { Objection, Profile, Stage } from '../data/playbook';
import { ChatMessage, chat, extractJson } from './openrouter';
import { Turn } from './audio';

export type Cue = {
  stage: string;
  say: string;
  why: string;
  objection: string | null;
  temperature: 'cold' | 'warm' | 'hot';
  missed: string[];
};

/**
 * Keyword pass over the prospect's last line. Runs in microseconds, so the
 * objection panel is up before the model has finished its first token.
 */
export function detectObjection(text: string, objections: Objection[]): Objection | null {
  const haystack = text.toLowerCase();
  let best: { obj: Objection; score: number } | null = null;

  for (const obj of objections) {
    for (const trigger of obj.triggers) {
      if (haystack.includes(trigger.toLowerCase())) {
        const score = trigger.length;
        if (!best || score > best.score) best = { obj, score };
      }
    }
  }
  return best?.obj ?? null;
}

function profileBlock(p: Profile) {
  return [
    p.offer && `Offer: ${p.offer}`,
    p.problemSolved && `Problem it solves: ${p.problemSolved}`,
    p.avatar && `Who they sell to: ${p.avatar}`,
    p.price && `Price: ${p.price}`,
    p.pillars.filter(Boolean).length && `Three pillars: ${p.pillars.filter(Boolean).join(' | ')}`,
  ]
    .filter(Boolean)
    .join('\n');
}

function playbookBlock(stages: Stage[], objections: Objection[]) {
  const s = stages
    .map(
      (st, i) =>
        `${i + 1}. ${st.name} — ${st.purpose}\n   Target: ${st.outcome}\n   Move on when: ${st.advanceWhen}\n   Lines:\n${st.lines
          .map((l) => `     - ${l.say}${l.note ? `  (${l.note})` : ''}`)
          .join('\n')}`
    )
    .join('\n\n');

  const o = objections
    .map((ob) => `${ob.name} (${ob.kind}):\n${ob.steps.map((x) => `  - ${x}`).join('\n')}`)
    .join('\n\n');

  return `STAGES\n${s}\n\nOBJECTIONS AND FRAMES\n${o}`;
}

function transcriptBlock(turns: Turn[], limit = 22) {
  return turns
    .slice(-limit)
    .map((t) => `${t.speaker === 'rep' ? 'ME' : 'PROSPECT'}: ${t.text}`)
    .join('\n');
}

const CUE_SYSTEM = `You are a live sales coach sitting on a call. The rep can only glance at you for about one second, so everything you produce must be readable at a glance.

Rules:
- "say" is the exact words the rep should speak next. First person, spoken English, under 30 words. Never describe what to do — write what to say.
- Fill every placeholder using what the prospect actually said. Never output curly braces.
- Follow the playbook's stage order. Do not jump to the close before emotional certainty is done.
- If the prospect raised an objection, "say" must come from the matching objection or frame.
- "missed" lists playbook targets for the current stage the rep skipped. Empty array if none.
- Reply with JSON only. No prose, no code fences.

Schema: {"stage":"<stage name>","say":"<exact words>","why":"<max 12 words>","objection":"<name or null>","temperature":"cold|warm|hot","missed":["..."]}`;

export async function getCue(args: {
  key: string;
  model: string;
  turns: Turn[];
  stages: Stage[];
  objections: Objection[];
  profile: Profile;
  currentStage: string;
  signal?: AbortSignal;
}): Promise<Cue | null> {
  const messages: ChatMessage[] = [
    { role: 'system', content: CUE_SYSTEM },
    {
      role: 'user',
      content: `MY PLAYBOOK\n${playbookBlock(args.stages, args.objections)}\n\nMY OFFER\n${
        profileBlock(args.profile) || '(not filled in — keep the line generic)'
      }\n\nCALL SO FAR\n${transcriptBlock(args.turns)}\n\nRep believes they are in stage: ${
        args.currentStage
      }. What do I say next?`,
    },
  ];

  const raw = await chat(args.key, args.model, messages, {
    temperature: 0.3,
    maxTokens: 320,
    signal: args.signal,
  });
  return extractJson<Cue>(raw);
}

export async function getRoleplayReply(args: {
  key: string;
  model: string;
  persona: string;
  difficulty: string;
  profile: Profile;
  history: ChatMessage[];
}): Promise<string> {
  const system = `You are roleplaying a sales PROSPECT so a rep can practise. Stay in character no matter what.

Character: ${args.persona}
Difficulty: ${args.difficulty}

How to behave:
- Speak like a real person on a call. One to three sentences. Contractions, hesitation, half-finished thoughts.
- Do not volunteer your pain. Make the rep dig for it.
- Raise objections naturally when the rep pushes: money, time, partner, "let me think about it".
- If the rep genuinely handles an objection well, soften. If they pitch too early or talk over you, get shorter and colder.
- Never coach, never break character, never mention you are an AI.

${profileBlock(args.profile) ? `What they are selling you:\n${profileBlock(args.profile)}` : ''}`;

  return chat(args.key, args.model, [{ role: 'system', content: system }, ...args.history], {
    temperature: 0.9,
    maxTokens: 220,
  });
}

export type Scorecard = {
  score: number;
  headline: string;
  talkRatio: string;
  stages: { name: string; covered: boolean; note: string }[];
  strengths: string[];
  mistakes: string[];
  nextCall: string[];
};

export async function getScorecard(args: {
  key: string;
  model: string;
  turns: Turn[];
  stages: Stage[];
  objections: Objection[];
  profile: Profile;
}): Promise<Scorecard | null> {
  const repWords = args.turns.filter((t) => t.speaker === 'rep').reduce((n, t) => n + t.text.split(/\s+/).length, 0);
  const proWords = args.turns.filter((t) => t.speaker === 'prospect').reduce((n, t) => n + t.text.split(/\s+/).length, 0);
  const total = repWords + proWords || 1;
  const ratio = `${Math.round((repWords / total) * 100)}% me / ${Math.round((proWords / total) * 100)}% prospect`;

  const system = `You grade sales calls against the rep's own playbook. Be direct and specific. Cite what was actually said. No encouragement padding — the rep wants to fix things, not feel good.

A rep talking more than 40% of the time on a discovery call is a problem. Say so.

Reply with JSON only, no fences.
Schema: {"score":0-100,"headline":"<one blunt sentence>","talkRatio":"<comment on the split>","stages":[{"name":"...","covered":true,"note":"..."}],"strengths":["..."],"mistakes":["..."],"nextCall":["..."]}`;

  const raw = await chat(
    args.key,
    args.model,
    [
      { role: 'system', content: system },
      {
        role: 'user',
        content: `PLAYBOOK\n${playbookBlock(args.stages, args.objections)}\n\nMEASURED TALK RATIO\n${ratio}\n\nFULL TRANSCRIPT\n${transcriptBlock(
          args.turns,
          400
        )}`,
      },
    ],
    { temperature: 0.2, maxTokens: 1100 }
  );

  const parsed = extractJson<Scorecard>(raw);
  if (parsed && !parsed.talkRatio) parsed.talkRatio = ratio;
  return parsed;
}
