import { DEFAULT_PROFILE, Profile, STAGES, OBJECTIONS, Stage, Objection } from '../data/playbook';

export type Settings = {
  openrouterKey: string;
  model: string;
  sttEndpoint: string;
  sttKey: string;
  sttModel: string;
  chunkSeconds: number;
  consentAcknowledged: boolean;
};

export const FREE_MODELS = [
  { id: 'deepseek/deepseek-chat-v3-0324:free', label: 'DeepSeek V3 — fastest, best default' },
  { id: 'z-ai/glm-4.5-air:free', label: 'GLM 4.5 Air — quick, good at instructions' },
  { id: 'qwen/qwen3-235b-a22b:free', label: 'Qwen3 235B — strongest reasoning, slower' },
  { id: 'moonshotai/kimi-k2:free', label: 'Kimi K2 — long context' },
  { id: 'deepseek/deepseek-r1:free', label: 'DeepSeek R1 — thinks first, too slow for live' },
];

export const DEFAULT_SETTINGS: Settings = {
  openrouterKey: '',
  model: FREE_MODELS[0].id,
  sttEndpoint: 'https://api.siliconflow.cn/v1/audio/transcriptions',
  sttKey: '',
  sttModel: 'FunAudioLLM/SenseVoiceSmall',
  chunkSeconds: 5,
  consentAcknowledged: false,
};

const KEY = 'salesgod.v1';

type Saved = {
  settings: Settings;
  profile: Profile;
  stages: Stage[];
  objections: Objection[];
};

export function load(): Saved {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) throw new Error('empty');
    const parsed = JSON.parse(raw);
    return {
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) },
      profile: { ...DEFAULT_PROFILE, ...(parsed.profile || {}) },
      stages: parsed.stages?.length ? parsed.stages : STAGES,
      objections: parsed.objections?.length ? parsed.objections : OBJECTIONS,
    };
  } catch {
    return { settings: DEFAULT_SETTINGS, profile: DEFAULT_PROFILE, stages: STAGES, objections: OBJECTIONS };
  }
}

export function save(data: Partial<Saved>) {
  const current = load();
  localStorage.setItem(KEY, JSON.stringify({ ...current, ...data }));
}

export function resetPlaybook() {
  save({ stages: STAGES, objections: OBJECTIONS });
}
