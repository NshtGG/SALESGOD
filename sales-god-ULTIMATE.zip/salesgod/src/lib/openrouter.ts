export type ChatMessage = { role: 'system' | 'user' | 'assistant'; content: string };

const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

export async function chat(
  key: string,
  model: string,
  messages: ChatMessage[],
  opts: { temperature?: number; maxTokens?: number; signal?: AbortSignal } = {}
): Promise<string> {
  if (!key) throw new Error('Add your OpenRouter key in Settings first.');

  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': location.origin,
      'X-Title': 'Sales God',
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 700,
    }),
    signal: opts.signal,
  });

  if (!res.ok) {
    const body = await res.text();
    if (res.status === 429) throw new Error('Free tier rate limit hit. Wait a moment or switch model in Settings.');
    if (res.status === 401) throw new Error('OpenRouter rejected the key. Check it in Settings.');
    throw new Error(`OpenRouter ${res.status}: ${body.slice(0, 200)}`);
  }

  const data = await res.json();
  return data?.choices?.[0]?.message?.content ?? '';
}

// Free models sometimes wrap JSON in prose or fences. Dig it out rather than throwing.
export function extractJson<T>(text: string): T | null {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf('{');
  const end = candidate.lastIndexOf('}');
  if (start === -1 || end === -1) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1)) as T;
  } catch {
    return null;
  }
}
