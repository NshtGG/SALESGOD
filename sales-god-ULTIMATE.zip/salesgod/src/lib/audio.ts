// Two channels, two very different capture problems.
//
// PROSPECT  — comes out of your speakers/headphones. Captured with
//             getDisplayMedia({ audio: true }), chunked, and sent to a
//             Whisper-compatible endpoint. Chrome and Edge only.
// YOU       — your microphone. Handled by the browser's own free speech
//             recogniser, so there is no per-minute cost on your own voice.

export type Turn = { speaker: 'prospect' | 'rep'; text: string; at: number };

export function captureSupported() {
  return !!navigator.mediaDevices?.getDisplayMedia;
}

export function speechSupported() {
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
}

/**
 * Asks for the tab or screen whose audio we should listen to. The video track
 * is stopped immediately — we only ever wanted the sound.
 */
export async function captureSystemAudio(): Promise<MediaStream> {
  const stream = await navigator.mediaDevices.getDisplayMedia({
    video: true,
    audio: {
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
    },
  });

  if (stream.getAudioTracks().length === 0) {
    stream.getTracks().forEach((t) => t.stop());
    throw new Error(
      'That share had no audio. Pick a Chrome tab and tick "Also share tab audio", or on Windows pick Entire Screen and tick "Share system audio".'
    );
  }

  stream.getVideoTracks().forEach((t) => {
    t.stop();
    stream.removeTrack(t);
  });

  return stream;
}

/**
 * Records the prospect stream in self-contained slices. Each slice is a fresh
 * MediaRecorder session, because only the first blob of a recording carries the
 * container header — continuing chunks are unplayable on their own.
 */
export class ChunkedTranscriber {
  private stream: MediaStream;
  private seconds: number;
  private onText: (text: string) => void;
  private onError: (msg: string) => void;
  private transcribe: (blob: Blob) => Promise<string>;
  private recorder: MediaRecorder | null = null;
  private timer: number | null = null;
  private running = false;

  constructor(opts: {
    stream: MediaStream;
    seconds: number;
    transcribe: (blob: Blob) => Promise<string>;
    onText: (text: string) => void;
    onError: (msg: string) => void;
  }) {
    this.stream = opts.stream;
    this.seconds = opts.seconds;
    this.transcribe = opts.transcribe;
    this.onText = opts.onText;
    this.onError = opts.onError;
  }

  start() {
    this.running = true;
    this.cycle();
  }

  stop() {
    this.running = false;
    if (this.timer) window.clearTimeout(this.timer);
    try {
      this.recorder?.stop();
    } catch {
      /* already stopped */
    }
    this.recorder = null;
  }

  private cycle() {
    if (!this.running) return;

    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
      ? 'audio/webm;codecs=opus'
      : 'audio/webm';

    const rec = new MediaRecorder(this.stream, { mimeType: mime });
    const parts: Blob[] = [];
    this.recorder = rec;

    rec.ondataavailable = (e) => {
      if (e.data.size > 0) parts.push(e.data);
    };

    rec.onstop = async () => {
      const blob = new Blob(parts, { type: mime });
      this.cycle(); // start the next slice before waiting on the network
      // Below ~8KB it is almost certainly silence. Skip the round trip.
      if (blob.size < 8000) return;
      try {
        const text = (await this.transcribe(blob)).trim();
        if (text) this.onText(text);
      } catch (err) {
        this.onError(err instanceof Error ? err.message : String(err));
      }
    };

    rec.start();
    this.timer = window.setTimeout(() => {
      if (rec.state !== 'inactive') rec.stop();
    }, this.seconds * 1000);
  }
}

export async function whisperTranscribe(
  blob: Blob,
  endpoint: string,
  key: string,
  model: string
): Promise<string> {
  if (!key) throw new Error('Add a speech-to-text key in Settings to hear the prospect.');

  const form = new FormData();
  form.append('file', blob, 'chunk.webm');
  form.append('model', model);

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}` },
    body: form,
  });

  if (!res.ok) throw new Error(`Speech-to-text ${res.status}: ${(await res.text()).slice(0, 160)}`);
  const data = await res.json();
  return data.text ?? '';
}

/** Wraps the browser's own recogniser for your side of the call. */
export class MicListener {
  private rec: any = null;
  private running = false;
  private onFinal: (text: string) => void;
  private onInterim: (text: string) => void;

  constructor(onFinal: (text: string) => void, onInterim: (text: string) => void) {
    this.onFinal = onFinal;
    this.onInterim = onInterim;
  }

  start() {
    const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!Ctor) return;

    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'en-US';

    rec.onresult = (e: any) => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const chunk = e.results[i][0].transcript;
        if (e.results[i].isFinal) this.onFinal(chunk.trim());
        else interim += chunk;
      }
      this.onInterim(interim.trim());
    };

    // Chrome silently ends the session every so often. Restart it.
    rec.onend = () => {
      if (this.running) {
        try {
          rec.start();
        } catch {
          /* racing a pending start */
        }
      }
    };

    this.rec = rec;
    this.running = true;
    rec.start();
  }

  stop() {
    this.running = false;
    try {
      this.rec?.stop();
    } catch {
      /* already stopped */
    }
    this.rec = null;
  }
}
