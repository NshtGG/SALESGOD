import { useEffect, useState } from 'react';
import { Objection, Profile, Stage } from './data/playbook';
import { Settings as S, load, resetPlaybook, save } from './lib/store';
import { Turn } from './lib/audio';
import Live from './views/Live';
import Roleplay from './views/Roleplay';
import PlaybookView from './views/Playbook';
import Objections from './views/Objections';
import Debrief from './views/Debrief';
import SettingsView from './views/Settings';

type Tab = 'live' | 'roleplay' | 'playbook' | 'objections' | 'debrief' | 'settings';

const TABS: { id: Tab; label: string }[] = [
  { id: 'live', label: 'Live call' },
  { id: 'roleplay', label: 'Roleplay' },
  { id: 'debrief', label: 'Debrief' },
  { id: 'playbook', label: 'Playbook' },
  { id: 'objections', label: 'Objections' },
  { id: 'settings', label: 'Settings' },
];

export default function App() {
  const initial = load();
  const [tab, setTab] = useState<Tab>('live');
  const [settings, setSettings] = useState<S>(initial.settings);
  const [profile, setProfile] = useState<Profile>(initial.profile);
  const [stages, setStages] = useState<Stage[]>(initial.stages);
  const [objections, setObjections] = useState<Objection[]>(initial.objections);
  const [lastCall, setLastCall] = useState<Turn[]>([]);

  useEffect(() => { save({ settings }); }, [settings]);
  useEffect(() => { save({ profile }); }, [profile]);
  useEffect(() => { save({ stages }); }, [stages]);

  function finishCall(turns: Turn[]) {
    setLastCall(turns);
    setTab('debrief');
  }

  function reset() {
    resetPlaybook();
    const fresh = load();
    setStages(fresh.stages);
    setObjections(fresh.objections);
  }

  return (
    <div className="shell">
      <nav className="rail">
        <div className="brand">
          <b>Sales God</b>
          <span>Novus Ordo</span>
        </div>
        {TABS.map((t) => (
          <button key={t.id} aria-current={tab === t.id} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
        <div className="rail-foot">
          {settings.openrouterKey ? settings.model.split('/')[1] : 'No key yet'}
        </div>
      </nav>

      <main className="main">
        {tab === 'live' && (
          <Live
            settings={settings}
            profile={profile}
            stages={stages}
            objections={objections}
            onEnd={finishCall}
          />
        )}
        {tab === 'roleplay' && (
          <Roleplay settings={settings} profile={profile} onEnd={finishCall} />
        )}
        {tab === 'debrief' && (
          <Debrief
            settings={settings}
            profile={profile}
            stages={stages}
            objections={objections}
            turns={lastCall}
          />
        )}
        {tab === 'playbook' && (
          <PlaybookView
            profile={profile}
            stages={stages}
            onProfile={setProfile}
            onStages={setStages}
            onReset={reset}
          />
        )}
        {tab === 'objections' && <Objections objections={objections} />}
        {tab === 'settings' && <SettingsView settings={settings} onChange={setSettings} />}
      </main>
    </div>
  );
}
