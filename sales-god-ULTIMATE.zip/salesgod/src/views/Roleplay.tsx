import { useEffect, useRef, useState } from 'react';
import { Profile } from '../data/playbook';
import { Settings } from '../lib/store';
import { ChatMessage } from '../lib/openrouter';
import { getRoleplayReply } from '../lib/coach';
import { Turn } from '../lib/audio';

const PERSONAS = [
  'Roofing company owner, 52, twelve crews, been burned by a marketing agency before',
  'Construction firm operations director, cautious, has to run everything past the owner',
  'Solo contractor, growing fast, no time, answers in half-sentences',
  'Skeptical buyer who has heard every pitch and opens with "just send me pricing"',
];

const LEVELS = [
  { id: 'warm', label: 'Warm — leans in, objects once, closeable' },
  { id: 'normal', label: 'Normal — guarded, two real objections' },
  { id: 'brutal', label: 'Brutal — cold, interrupts, price-anchors early' },
];

type Props = { settings: Settings; profile: Profile; onEnd: (turns: Turn[]) => void };

export default function Roleplay({ settings, profile, onEnd }: Props) {
  const [persona, setPersona] = useState(PERSONAS[0]);
  const [level, setLevel] = useState(LEVELS[1].id);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [history, busy]);

  async function send() {
    const text = draft.trim();
    if (!text || busy) return;
    const next: ChatMessage[] = [...history, { role: 'user', content: text }];
    setHistory(next);
    setDraft('');
    setBusy(true);
    setError('');
    try {
      const reply = await getRoleplayReply({
        key: settings.openrouterKey,
        model: settings.model,
        persona,
        difficulty: LEVELS.find((l) => l.id === level)?.label ?? level,
        profile,
        history: next,
      });
      setHistory([...next, { role: 'assistant', content: reply }]);
    } catch (err) {
      setError((err as Error).message);
      setHistory(history);
      setDraft(text);
    } finally {
      setBusy(false);
    }
  }

  function finish() {
    const turns: Turn[] = history.map((m, i) => ({
      speaker: m.role === 'user' ? 'rep' : 'prospect',
      text: m.content,
      at: Date.now() + i,
    }));
    onEnd(turns);
  }

  const started = history.length > 0;

  return (
    <>
      <h1>Roleplay</h1>
      <p className="lede">
        Run the script against a prospect who pushes back. Nothing here touches your microphone, so
        you can practise anywhere.
      </p>

      {!started && (
        <div className="card" style={{ marginBottom: 20, maxWidth: 640 }}>
          <label className="field">
            <span>Who you are calling</span>
            <select value={persona} onChange={(e) => setPersona(e.target.value)}>
              {PERSONAS.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <label className="field" style={{ marginBottom: 0 }}>
            <span>How hard they push</span>
            <select value={level} onChange={(e) => setLevel(e.target.value)}>
              {LEVELS.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      )}

      <div className="card" style={{ maxWidth: 760 }}>
        <div className="chat" ref={scrollRef}>
          {!started && <p className="empty">Open the call. First line is yours.</p>}
          {history.map((m, i) => (
            <div key={i} className={`bubble ${m.role === 'user' ? 'me' : 'them'}`}>
              {m.content}
            </div>
          ))}
          {busy && <div className="bubble them" style={{ color: 'var(--muted)' }}>…</div>}
        </div>

        {error && <p className="note warn" style={{ margin: '14px 0 0' }}>{error}</p>}

        <div className="row" style={{ marginTop: 16 }}>
          <input
            type="text"
            value={draft}
            placeholder="What you say next"
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send()}
            style={{ flex: 1, minWidth: 240 }}
          />
          <button className="btn primary" onClick={send} disabled={busy || !draft.trim()}>
            Say it
          </button>
        </div>
      </div>

      {started && (
        <div className="row" style={{ marginTop: 18 }}>
          <button className="btn" onClick={finish}>
            Score this roleplay
          </button>
          <button className="btn" onClick={() => setHistory([])}>
            Start over
          </button>
        </div>
      )}
    </>
  );
}
