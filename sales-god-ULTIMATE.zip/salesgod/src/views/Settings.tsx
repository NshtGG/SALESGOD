import { FREE_MODELS, Settings as S } from '../lib/store';

type Props = { settings: S; onChange: (s: S) => void };

const STT_PRESETS = [
  {
    label: 'SiliconFlow — SenseVoice (Chinese, free tier)',
    endpoint: 'https://api.siliconflow.cn/v1/audio/transcriptions',
    model: 'FunAudioLLM/SenseVoiceSmall',
    signup: 'https://cloud.siliconflow.cn',
  },
  {
    label: 'Groq — Whisper Large v3 Turbo (free tier, fastest)',
    endpoint: 'https://api.groq.com/openai/v1/audio/transcriptions',
    model: 'whisper-large-v3-turbo',
    signup: 'https://console.groq.com',
  },
];

export default function Settings({ settings, onChange }: Props) {
  const set = (patch: Partial<S>) => onChange({ ...settings, ...patch });

  return (
    <>
      <h1>Settings</h1>
      <p className="lede">
        Keys live in this browser only. Nothing is sent anywhere except the two providers below.
      </p>

      <div className="card" style={{ marginBottom: 20, maxWidth: 680 }}>
        <b style={{ fontWeight: 600, display: 'block', marginBottom: 14 }}>Coaching model</b>
        <label className="field">
          <span>OpenRouter API key</span>
          <input
            type="password"
            value={settings.openrouterKey}
            placeholder="sk-or-v1-…"
            onChange={(e) => set({ openrouterKey: e.target.value })}
          />
        </label>
        <label className="field" style={{ marginBottom: 8 }}>
          <span>Model</span>
          <select value={settings.model} onChange={(e) => set({ model: e.target.value })}>
            {FREE_MODELS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
        </label>
        <p className="note">
          All free tier. OpenRouter renames and retires free models regularly — if one starts
          returning 404, check openrouter.ai/models and paste the new id into src/lib/store.ts.
          Reasoning models think before answering, which costs you two or three seconds you do not
          have mid-call.
        </p>
      </div>

      <div className="card" style={{ marginBottom: 20, maxWidth: 680 }}>
        <b style={{ fontWeight: 600, display: 'block', marginBottom: 14 }}>Hearing the prospect</b>
        <label className="field">
          <span>Provider</span>
          <select
            value={settings.sttEndpoint}
            onChange={(e) => {
              const preset = STT_PRESETS.find((p) => p.endpoint === e.target.value);
              if (preset) set({ sttEndpoint: preset.endpoint, sttModel: preset.model });
            }}
          >
            {STT_PRESETS.map((p) => (
              <option key={p.endpoint} value={p.endpoint}>
                {p.label}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Speech-to-text key</span>
          <input
            type="password"
            value={settings.sttKey}
            onChange={(e) => set({ sttKey: e.target.value })}
          />
        </label>
        <label className="field">
          <span>Seconds of audio per slice</span>
          <input
            type="number"
            min={3}
            max={12}
            value={settings.chunkSeconds}
            onChange={(e) => set({ chunkSeconds: Number(e.target.value) || 5 })}
          />
        </label>
        <p className="note">
          Shorter slices mean a faster cue but more requests against the free tier. Five seconds is
          the sweet spot. Your own voice uses Chrome's built-in recogniser and costs nothing.
        </p>
      </div>

      <div className="card" style={{ maxWidth: 680 }}>
        <b style={{ fontWeight: 600, display: 'block', marginBottom: 10 }}>Recording consent</b>
        <p style={{ marginTop: 0 }}>
          Sales God transcribes the other person's voice. Several US states, the UK and most of the
          EU require everyone on the call to know. Say it in your opener — "I've got a notetaker
          running, that alright?" — and you are covered almost everywhere.
        </p>
        <label className="row" style={{ cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={settings.consentAcknowledged}
            onChange={(e) => set({ consentAcknowledged: e.target.checked })}
            style={{ width: 'auto' }}
          />
          <span>I'll get consent before transcribing a call.</span>
        </label>
      </div>
    </>
  );
}
