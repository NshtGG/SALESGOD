import { useState } from 'react';
import { Objection } from '../data/playbook';

export default function Objections({ objections }: { objections: Objection[] }) {
  const [q, setQ] = useState('');

  const needle = q.trim().toLowerCase();
  const shown = needle
    ? objections.filter(
        (o) =>
          o.name.toLowerCase().includes(needle) ||
          o.triggers.some((t) => t.includes(needle)) ||
          o.steps.some((s) => s.toLowerCase().includes(needle))
      )
    : objections;

  return (
    <>
      <h1>Objections</h1>
      <p className="lede">
        The three stalls and the four reframes, in order. Sales God pulls from these automatically
        mid-call, but read them cold until you do not need to.
      </p>

      <input
        type="text"
        value={q}
        placeholder="Search — try money, wife, think about it"
        onChange={(e) => setQ(e.target.value)}
        style={{ maxWidth: 420, marginBottom: 22 }}
      />

      {shown.length === 0 && <p className="empty">Nothing matches that.</p>}

      {shown.map((o) => (
        <div className="card" key={o.id} style={{ marginBottom: 14, maxWidth: 780 }}>
          <div className="row" style={{ marginBottom: 12 }}>
            <b style={{ fontWeight: 600, fontSize: 16 }}>{o.name}</b>
            <span style={{ color: 'var(--muted)', fontSize: 13 }}>
              {o.kind === 'frame' ? 'Reframe' : 'Stall'}
            </span>
          </div>
          <ol className="steps">
            {o.steps.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ol>
          <p className="cue-why">Fires on: {o.triggers.slice(0, 6).join(', ')}</p>
        </div>
      ))}
    </>
  );
}
