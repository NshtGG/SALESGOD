import { useState } from 'react';
import { Profile, Stage } from '../data/playbook';

type Props = {
  profile: Profile;
  stages: Stage[];
  onProfile: (p: Profile) => void;
  onStages: (s: Stage[]) => void;
  onReset: () => void;
};

export default function Playbook({ profile, stages, onProfile, onStages, onReset }: Props) {
  const [open, setOpen] = useState<string | null>(stages[0]?.id ?? null);

  function editStage(id: string, patch: Partial<Stage>) {
    onStages(stages.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }

  function editLine(id: string, index: number, say: string) {
    const stage = stages.find((s) => s.id === id);
    if (!stage) return;
    const lines = stage.lines.map((l, i) => (i === index ? { ...l, say } : l));
    editStage(id, { lines });
  }

  return (
    <>
      <h1>Playbook</h1>
      <p className="lede">
        Your VIP closing script, loaded and editable. Fill in the offer first — every placeholder in
        a cue gets filled from here plus what the prospect actually said.
      </p>

      <div className="card" style={{ marginBottom: 24, maxWidth: 720 }}>
        <b style={{ fontWeight: 600, display: 'block', marginBottom: 14 }}>Your offer</b>
        <label className="field">
          <span>What you sell</span>
          <input
            type="text"
            value={profile.offer}
            placeholder="Done-for-you lead generation for roofing companies"
            onChange={(e) => onProfile({ ...profile, offer: e.target.value })}
          />
        </label>
        <label className="field">
          <span>Problem it solves</span>
          <input
            type="text"
            value={profile.problemSolved}
            placeholder="Owners relying on referrals with no predictable pipeline"
            onChange={(e) => onProfile({ ...profile, problemSolved: e.target.value })}
          />
        </label>
        <label className="field">
          <span>Who you sell to</span>
          <input
            type="text"
            value={profile.avatar}
            placeholder="Roofing and construction owners, 5 to 50 crews, US and UK"
            onChange={(e) => onProfile({ ...profile, avatar: e.target.value })}
          />
        </label>
        <label className="field">
          <span>Price you say out loud</span>
          <input
            type="text"
            value={profile.price}
            placeholder="$6,000 upfront, or 3 x $2,200"
            onChange={(e) => onProfile({ ...profile, price: e.target.value })}
          />
        </label>
        {profile.pillars.map((p, i) => (
          <label className="field" key={i} style={i === 2 ? { marginBottom: 0 } : undefined}>
            <span>Pillar {i + 1}</span>
            <input
              type="text"
              value={p}
              placeholder={i === 0 ? 'Name it, then say which problem it kills' : ''}
              onChange={(e) => {
                const pillars = [...profile.pillars];
                pillars[i] = e.target.value;
                onProfile({ ...profile, pillars });
              }}
            />
          </label>
        ))}
      </div>

      {stages.map((s, i) => (
        <div className="card" key={s.id} style={{ marginBottom: 12 }}>
          <button
            className="row"
            style={{ background: 'none', border: 0, cursor: 'pointer', padding: 0, width: '100%' }}
            onClick={() => setOpen(open === s.id ? null : s.id)}
          >
            <em style={{ fontFamily: 'var(--mono)', fontStyle: 'normal', color: 'var(--muted)' }}>{i + 1}</em>
            <b style={{ fontWeight: 600 }}>{s.name}</b>
            <span style={{ color: 'var(--muted)', fontSize: 13 }}>{s.purpose}</span>
          </button>

          {open === s.id && (
            <div style={{ marginTop: 16 }}>
              <label className="field">
                <span>Move on when</span>
                <input
                  type="text"
                  value={s.advanceWhen}
                  onChange={(e) => editStage(s.id, { advanceWhen: e.target.value })}
                />
              </label>
              {s.lines.map((l, li) => (
                <label className="field" key={li}>
                  <span>{l.note ?? `Line ${li + 1}`}</span>
                  <textarea value={l.say} onChange={(e) => editLine(s.id, li, e.target.value)} />
                </label>
              ))}
              <button
                className="btn"
                onClick={() => editStage(s.id, { lines: [...s.lines, { say: '' }] })}
              >
                Add a line
              </button>
            </div>
          )}
        </div>
      ))}

      <button className="btn danger" style={{ marginTop: 16 }} onClick={onReset}>
        Reset to the original script
      </button>
    </>
  );
}
