import { useState } from 'react';
import { Objection, Profile, Stage } from '../data/playbook';
import { Settings } from '../lib/store';
import { Turn } from '../lib/audio';
import { Scorecard, getScorecard } from '../lib/coach';

type Props = {
  settings: Settings;
  profile: Profile;
  stages: Stage[];
  objections: Objection[];
  turns: Turn[];
};

export default function Debrief({ settings, profile, stages, objections, turns }: Props) {
  const [card, setCard] = useState<Scorecard | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function run() {
    setBusy(true);
    setError('');
    try {
      const result = await getScorecard({
        key: settings.openrouterKey,
        model: settings.model,
        turns,
        stages,
        objections,
        profile,
      });
      if (!result) throw new Error('The model returned something unreadable. Try again, or switch model in Settings.');
      setCard(result);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function download() {
    const body = turns.map((t) => `${t.speaker === 'rep' ? 'ME' : 'PROSPECT'}: ${t.text}`).join('\n');
    const url = URL.createObjectURL(new Blob([body], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `call-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!turns.length) {
    return (
      <>
        <h1>Debrief</h1>
        <p className="lede">Finish a live call or a roleplay, then come back here for the grade.</p>
      </>
    );
  }

  return (
    <>
      <h1>Debrief</h1>
      <p className="lede">{turns.length} turns captured. Graded against your own playbook, not a generic rubric.</p>

      <div className="row" style={{ marginBottom: 22 }}>
        <button className="btn primary" onClick={run} disabled={busy}>
          {busy ? 'Grading…' : card ? 'Grade again' : 'Grade this call'}
        </button>
        <button className="btn" onClick={download}>
          Download transcript
        </button>
      </div>

      {error && <p className="note warn">{error}</p>}

      {card && (
        <>
          <div className="card" style={{ marginBottom: 20 }}>
            <div className="score">
              {card.score}
              <small> / 100</small>
            </div>
            <p style={{ margin: '10px 0 0', maxWidth: '58ch' }}>{card.headline}</p>
            <p className="cue-why">{card.talkRatio}</p>
          </div>

          <div className="card" style={{ marginBottom: 20 }}>
            <b style={{ fontWeight: 600 }}>Stage coverage</b>
            <div style={{ marginTop: 10 }}>
              {card.stages?.map((s, i) => (
                <div key={i} className="checkline">
                  <span className="dot" style={{ background: s.covered ? 'var(--ok)' : 'var(--alert)' }} />
                  <b>{s.name}</b>
                  <span>{s.note}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid2">
            <div className="card">
              <b style={{ fontWeight: 600 }}>What worked</b>
              <ul className="steps" style={{ marginTop: 10 }}>
                {card.strengths?.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
            <div className="card">
              <b style={{ fontWeight: 600 }}>What cost you</b>
              <ul className="steps" style={{ marginTop: 10 }}>
                {card.mistakes?.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="card" style={{ marginTop: 20 }}>
            <b style={{ fontWeight: 600 }}>Do this on the next call</b>
            <ol className="steps" style={{ marginTop: 10 }}>
              {card.nextCall?.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          </div>
        </>
      )}

      <div className="card" style={{ marginTop: 20 }}>
        <b style={{ fontWeight: 600 }}>Transcript</b>
        <div className="transcript" style={{ marginTop: 12, maxHeight: 260 }}>
          {turns.map((t, i) => (
            <div key={i} className={`turn ${t.speaker}`}>
              <b>{t.speaker === 'rep' ? 'You' : 'Prospect'}</b>
              <span>{t.text}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
