import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Objection, Profile, Stage } from '../data/playbook';
import { Settings } from '../lib/store';
import {
  ChunkedTranscriber,
  MicListener,
  Turn,
  captureSupported,
  captureSystemAudio,
  speechSupported,
  whisperTranscribe,
} from '../lib/audio';
import { Cue, detectObjection, getCue } from '../lib/coach';

type Props = {
  settings: Settings;
  profile: Profile;
  stages: Stage[];
  objections: Objection[];
  onEnd: (turns: Turn[]) => void;
};

export default function Live({ settings, profile, stages, objections, onEnd }: Props) {
  const [live, setLive] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [interim, setInterim] = useState('');
  const [cue, setCue] = useState<Cue | null>(null);
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState('');
  const [stageId, setStageId] = useState(stages[0]?.id ?? 'intent');
  const [manual, setManual] = useState('');

  const streamRef = useRef<MediaStream | null>(null);
  const chunkerRef = useRef<ChunkedTranscriber | null>(null);
  const micRef = useRef<MicListener | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const debounceRef = useRef<number | null>(null);
  const pipRef = useRef<Window | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const turnsRef = useRef<Turn[]>([]);

  turnsRef.current = turns;

  const stage = stages.find((s) => s.id === stageId) ?? stages[0];

  const hit = useMemo(() => {
    const last = [...turns].reverse().find((t) => t.speaker === 'prospect');
    return last ? detectObjection(last.text, objections) : null;
  }, [turns, objections]);

  const addTurn = useCallback((speaker: Turn['speaker'], text: string) => {
    if (!text.trim()) return;
    setTurns((prev) => [...prev, { speaker, text: text.trim(), at: Date.now() }]);
  }, []);

  const askForCue = useCallback(async () => {
    if (!settings.openrouterKey) return;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setThinking(true);
    try {
      const next = await getCue({
        key: settings.openrouterKey,
        model: settings.model,
        turns: turnsRef.current,
        stages,
        objections,
        profile,
        currentStage: stage?.name ?? 'Intent',
        signal: controller.signal,
      });
      if (next) {
        setCue(next);
        setError('');
        const matched = stages.find((s) => s.name.toLowerCase() === String(next.stage).toLowerCase());
        if (matched) setStageId(matched.id);
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') setError((err as Error).message);
    } finally {
      setThinking(false);
    }
  }, [settings, stages, objections, profile, stage]);

  // Debounced so a burst of transcript slices costs one request, not five.
  useEffect(() => {
    if (!turns.length) return;
    if (turns[turns.length - 1].speaker !== 'prospect') return;
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(askForCue, 1100);
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [turns, askForCue]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [turns, interim]);

  async function start() {
    setError('');
    try {
      const stream = await captureSystemAudio();
      streamRef.current = stream;

      // The user can also kill the share from Chrome's own bar.
      stream.getAudioTracks()[0].addEventListener('ended', () => stop());

      const chunker = new ChunkedTranscriber({
        stream,
        seconds: settings.chunkSeconds,
        transcribe: (blob) =>
          whisperTranscribe(blob, settings.sttEndpoint, settings.sttKey, settings.sttModel),
        onText: (text) => addTurn('prospect', text),
        onError: (msg) => setError(msg),
      });
      chunker.start();
      chunkerRef.current = chunker;

      if (speechSupported()) {
        const mic = new MicListener(
          (text) => {
            setInterim('');
            addTurn('rep', text);
          },
          (text) => setInterim(text)
        );
        mic.start();
        micRef.current = mic;
      }

      setLive(true);
    } catch (err) {
      setError((err as Error).message);
    }
  }

  function stop() {
    chunkerRef.current?.stop();
    micRef.current?.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    chunkerRef.current = null;
    micRef.current = null;
    streamRef.current = null;
    setInterim('');
    setLive(false);
  }

  useEffect(() => () => stop(), []);

  /** Document Picture-in-Picture: a real always-on-top window over any app. */
  async function popOut() {
    const dpip = (window as any).documentPictureInPicture;
    if (!dpip) {
      setError('Your browser has no floating-window support. Use Chrome or Edge 116+.');
      return;
    }
    const w = await dpip.requestWindow({ width: 460, height: 240 });
    document.querySelectorAll('style, link[rel="stylesheet"]').forEach((node) => {
      w.document.head.appendChild(node.cloneNode(true));
    });
    const mount = w.document.createElement('div');
    mount.className = 'pip';
    mount.id = 'sg-pip';
    w.document.body.appendChild(mount);
    pipRef.current = w;
    w.addEventListener('pagehide', () => (pipRef.current = null));
  }

  // Mirror the current cue into the floating window whenever it changes.
  useEffect(() => {
    const w = pipRef.current;
    const mount = w?.document.getElementById('sg-pip');
    if (!mount) return;
    mount.innerHTML = `
      <div class="cue-meta">
        <span class="dot ${cue?.temperature ?? ''}"></span>
        <span>${cue?.stage ?? 'Waiting'}</span>
        ${cue?.objection ? `<span style="color:var(--alert)">${cue.objection}</span>` : ''}
      </div>
      <p class="cue-say">${cue?.say ?? 'Start the call.'}</p>
      ${cue?.why ? `<p class="cue-why">${cue.why}</p>` : ''}`;
  }, [cue]);

  const ready = settings.openrouterKey && settings.sttKey;

  return (
    <>
      <h1>Live call</h1>
      <p className="lede">
        Share the tab your call is running in and tick the audio box. Sales God hears the prospect
        through your speakers and writes your next line.
      </p>

      {!captureSupported() && (
        <div className="card" style={{ marginBottom: 20 }}>
          <p className="warn" style={{ margin: 0 }}>
            This browser cannot capture audio. Open Sales God in Chrome or Edge.
          </p>
        </div>
      )}

      {!ready && (
        <div className="card" style={{ marginBottom: 20 }}>
          <p style={{ margin: 0 }}>
            Add your OpenRouter key and a speech-to-text key in Settings before your first call.
          </p>
        </div>
      )}

      <div className="row" style={{ marginBottom: 20 }}>
        {live ? (
          <>
            <button className="btn danger" onClick={stop}>
              End call
            </button>
            <button className="btn" onClick={popOut}>
              Float the cue
            </button>
            <span className="row" style={{ gap: 7 }}>
              <span className="dot live" />
              <span style={{ color: 'var(--muted)', fontSize: 13 }}>
                {thinking ? 'Thinking' : 'Listening'}
              </span>
            </span>
          </>
        ) : (
          <>
            <button className="btn primary" onClick={start} disabled={!captureSupported()}>
              Start listening
            </button>
            {turns.length > 0 && (
              <button className="btn" onClick={() => onEnd(turns)}>
                Score this call
              </button>
            )}
            {turns.length > 0 && (
              <button
                className="btn"
                onClick={() => {
                  setTurns([]);
                  setCue(null);
                }}
              >
                Clear
              </button>
            )}
          </>
        )}
      </div>

      {error && (
        <p className="note warn" style={{ marginBottom: 18 }}>
          {error}
        </p>
      )}

      <div className="live">
        <div>
          <div className={`cue-card ${cue?.objection ? 'objection' : ''}`}>
            <div className="cue-meta">
              <span className={`dot ${cue?.temperature ?? ''}`} />
              <span>{cue?.stage ?? stage?.name ?? 'Intent'}</span>
              {cue?.objection && <span style={{ color: 'var(--alert)' }}>{cue.objection}</span>}
              {thinking && <span>writing…</span>}
            </div>
            <p className="cue-say">
              {cue?.say ?? (live ? 'Listening for the prospect…' : 'Your next line appears here.')}
            </p>
            {cue?.why && <p className="cue-why">{cue.why}</p>}
            {cue?.missed?.length ? (
              <p className="cue-why">
                Skipped: {cue.missed.join(' · ')}
              </p>
            ) : null}
          </div>

          <div className="card" style={{ marginTop: 20 }}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 12 }}>
              <b style={{ fontWeight: 600 }}>Transcript</b>
              <button className="btn" onClick={askForCue} disabled={!turns.length}>
                Re-ask
              </button>
            </div>
            <div className="transcript" ref={scrollRef}>
              {turns.length === 0 && <p className="empty">Nothing yet.</p>}
              {turns.map((t, i) => (
                <div key={i} className={`turn ${t.speaker}`}>
                  <b>{t.speaker === 'rep' ? 'You' : 'Prospect'}</b>
                  <span>{t.text}</span>
                </div>
              ))}
              {interim && (
                <div className="turn rep interim">
                  <b>You</b>
                  <span>{interim}</span>
                </div>
              )}
            </div>

            <div className="row" style={{ marginTop: 14 }}>
              <input
                type="text"
                value={manual}
                placeholder="Type what they said, if the audio missed it"
                onChange={(e) => setManual(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && manual.trim()) {
                    addTurn('prospect', manual);
                    setManual('');
                  }
                }}
                style={{ flex: 1, minWidth: 220 }}
              />
            </div>
          </div>
        </div>

        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            <b style={{ fontWeight: 600, display: 'block', marginBottom: 10 }}>Where you are</b>
            <div className="stage-rail">
              {stages.map((s, i) => (
                <button
                  key={s.id}
                  aria-current={s.id === stageId}
                  onClick={() => setStageId(s.id)}
                  title={s.purpose}
                >
                  <em>{i + 1}</em>
                  <span>{s.name}</span>
                </button>
              ))}
            </div>
            <p className="cue-why" style={{ marginTop: 12 }}>
              {stage?.outcome}
            </p>
          </div>

          {hit && (
            <div className="card">
              <div className="cue-meta">
                <span className="dot" style={{ background: 'var(--alert)' }} />
                <span>{hit.name}</span>
              </div>
              <ol className="steps">
                {hit.steps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ol>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
